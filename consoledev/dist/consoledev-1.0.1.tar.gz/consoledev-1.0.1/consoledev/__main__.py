def main():
    print("You launched it successfully ! ")


if __name__ == '__main__':
    main()
