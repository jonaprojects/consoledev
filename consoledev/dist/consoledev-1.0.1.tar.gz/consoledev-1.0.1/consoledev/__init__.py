# __init__.py

# Version of the consoledev package
__version__ = "1.0.1"

